/**
 * ASKNAIJA KNOWLEDGE BASE
 * NITIZEN Civic Intelligence Platform
 * Version 2.0 — Comprehensive Nigerian Civic Education Dataset
 *
 * TRANSPARENCY NOTICE:
 * This knowledge base is rule-based and deterministic — not a generative AI.
 * Every response is drawn from verified, sourced entries compiled by the NITIZEN
 * editorial team from official Nigerian government documents, legislation, NBS data,
 * academic literature, and reputable civic sources.
 * Sources are cited within each response. No information is fabricated.
 * Last updated: May 2026.
 *
 * CATEGORIES:
 * 1. Electoral Democracy & INEC
 * 2. Constitutional Rights & The Law
 * 3. Civic Duties & Responsibilities
 * 4. Political Knowledge & Nigeria's Democracy
 * 5. Nigerian History & Political Development
 * 6. Public Finance & Government Budgets
 * 7. Economic Policy & National Development
 * 8. Security & Rule of Law
 * 9. Health Policy & Social Services
 * 10. Education Policy
 * 11. Anti-Corruption & Accountability
 * 12. Sociopolitical Issues & National Cohesion
 * 13. Ethical Values & Public Morality
 * 14. Emerging Issues — Nigeria 2026
 * 15. Nigerian Institutions & How They Work
 */

const ASKNAIJA_KB = [

  // ═══════════════════════════════════
  // CATEGORY 1: ELECTORAL DEMOCRACY
  // ═══════════════════════════════════
  {
    id: 'voter-registration',
    category: 'Elections & Voting',
    keys: ['register','vote','voter','pvc','pvcs','2027','registration','polling unit','electoral','ballot'],
    question: 'How do I register to vote for the 2027 elections?',
    answer: `VOTER REGISTRATION FOR THE 2027 GENERAL ELECTIONS

To register as a voter in Nigeria, you must visit an INEC Voter Registration Centre in your Local Government Area during an open registration window. Here is the process:

REQUIREMENTS:
• Valid National Identity Number (NIN) — mandatory since 2021
• You must be 18 years of age or older
• You must be a Nigerian citizen
• Registration is free of charge — no fees at any point

STEPS:
1. Locate your nearest INEC registration centre at inec.gov.ng or call INEC's voter helpline
2. Present your NIN and any supporting ID
3. Your biometric data (fingerprints and photograph) will be captured
4. You will receive a voter registration slip as proof
5. Your Permanent Voter Card (PVC) is produced separately and must be collected at the same registration centre

IMPORTANT — PVC COLLECTION:
You must physically collect your PVC before election day. Without it, you cannot vote, even if you are fully registered. INEC periodically announces collection windows.

TRANSFER OF VOTING LOCATION:
If you have moved states or LGAs, you can request a voter transfer at the INEC portal (voters.inec.gov.ng).

INEC'S TIMETABLE:
INEC is required by the Electoral Act 2022 to publish its election timetable at least 360 days before any election. The 2027 general elections are expected to hold in February/March 2027. Continuous voter registration exercises are conducted periodically.

Source: Electoral Act 2022 (Sections 9–19); INEC Regulations and Guidelines 2022; inec.gov.ng`
  },

  {
    id: 'inec-role',
    category: 'Elections & Voting',
    keys: ['inec','electoral commission','umpire','election body','election commission','independent national'],
    question: 'What is INEC and what is its role?',
    answer: `THE INDEPENDENT NATIONAL ELECTORAL COMMISSION (INEC)

INEC is established under Section 153 and Third Schedule of the 1999 Constitution (as amended) and further regulated by the Electoral Act 2022.

CORE FUNCTIONS:
1. Conduct federal elections — presidential, National Assembly (Senate and House of Representatives)
2. Conduct governorship and state assembly elections
3. Conduct FCT Area Council elections
4. Register voters and issue Permanent Voter Cards (PVCs)
5. Register and deregister political parties
6. Compile, maintain, and update the National Register of Voters
7. Investigate and prosecute electoral offences (jointly with the police)
8. Demarcate federal and state constituencies
9. Publish election results transparently via the INEC Result Viewing Portal (IReV)

LEADERSHIP:
• INEC Chair is appointed by the President on the recommendation of the Council of State, subject to Senate confirmation
• The chair serves a single non-renewable 5-year term
• Each state has a Resident Electoral Commissioner (REC) appointed by the President

INEC STRUCTURE:
• National headquarters in Abuja
• 36 state offices and 1 FCT office
• 774 LGA offices across Nigeria
• Over 176,000 polling units nationwide

CHALLENGES DOCUMENTED:
The 2023 elections generated significant litigation over INEC's technical systems, particularly the BVAS (Bimodal Voter Accreditation System) and IReV portal failures. The Supreme Court upheld the presidential result; electoral reform advocacy continues ahead of 2027.

Source: 1999 Constitution (as amended), Third Schedule Part I; Electoral Act 2022; INEC Annual Report 2023`
  },

  {
    id: 'electoral-act-2022',
    category: 'Elections & Voting',
    keys: ['electoral act','electoral act 2022','election law','irev','bvas','electronic voting','bimodal'],
    question: 'What does the Electoral Act 2022 change about Nigerian elections?',
    answer: `THE ELECTORAL ACT 2022 — KEY REFORMS

Signed by President Muhammadu Buhari in February 2022, the Electoral Act 2022 represents the most significant reform of Nigeria's election framework since 2006. Key changes:

1. ELECTRONIC ACCREDITATION (BVAS):
The Bimodal Voter Accreditation System must be used to accredit all voters using fingerprint and facial recognition. This was designed to eliminate proxy voting and impersonation.

2. ELECTRONIC TRANSMISSION OF RESULTS (IReV):
INEC is required to upload polling unit results to its Result Viewing Portal (IReV) in real time. This is legally binding — any deviation requires documented justification. In 2023, implementation was disputed.

3. PARTY PRIMARIES:
Parties must conduct direct or indirect primaries; consensus candidacy without voting is now regulated. INEC must verify compliance.

4. INDEPENDENT CANDIDACY:
The Act does not yet permit independent candidacy — this remains a subject of ongoing constitutional debate.

5. EARLY VOTING:
Persons with disabilities and security personnel may vote before election day in some categories.

6. DIASPORA VOTING:
Not yet implemented. The Act empowers INEC to develop a framework but it has not been activated.

7. CAMPAIGN FINANCE:
Individual presidential candidates are capped at ₦5 billion for campaign spending; governorship candidates at ₦1 billion. INEC and the Independent Corrupt Practices Commission (ICPC) share oversight.

8. ELECTORAL OFFENCES:
Penalties for vote buying, ballot stuffing, and result falsification have been enhanced.

Source: Electoral Act 2022 (Act No. 10 of 2022); INEC Implementation Guidelines 2023`
  },

  {
    id: 'political-parties',
    category: 'Elections & Voting',
    keys: ['political party','parties','apc','pdp','lp','labour party','nnpp','apga','political parties'],
    question: 'What political parties are registered in Nigeria and how do they work?',
    answer: `POLITICAL PARTIES IN NIGERIA

As of 2025, INEC has 18 registered political parties. Registration requires national spread across at least 24 states.

MAJOR PARTIES (by current legislative representation):

APC — All Progressives Congress:
• Formed 2013 from merger of ACN, CPC, ANPP, and nPDP factions
• Currently holds the presidency (Tinubu), Senate majority, and most governorships
• Ideologically centre-right; liberal economic policy orientation

PDP — Peoples Democratic Party:
• Nigeria's longest-ruling party (1999–2015 at federal level)
• Holds significant state governorships and legislative seats
• Broad coalition party; no rigid ideology

LP — Labour Party:
• Surged in 2023 elections; Peter Obi's presidential run galvanised youth support
• Historically small; now a significant third force
• Social democratic orientation

NNPP — New Nigeria Peoples Party:
• Rabiu Kwankwaso's vehicle; strong in Kano
• Populist northern orientation

APGA — All Progressives Grand Alliance:
• Dominant in Anambra State; southeast orientation
• Charles Soludo (Anambra Governor) is its most prominent current figure

HOW PARTIES WORK:
• Must maintain secretariats in 24 states and FCT
• Must conduct primaries to select candidates
• Are funded by membership dues, donations, and candidate levies
• Must submit audited financial statements to INEC annually
• Can be deregistered for failing to win at least one seat in two consecutive general elections

Source: Electoral Act 2022; INEC Register of Political Parties 2025; Constitution Section 222–229`
  },

  // ═══════════════════════════════════
  // CATEGORY 2: CONSTITUTIONAL RIGHTS
  // ═══════════════════════════════════
  {
    id: 'fundamental-rights',
    category: 'Constitutional Rights',
    keys: ['rights','fundamental rights','constitution','constitutional','chapter iv','human rights','basic rights'],
    question: 'What are my fundamental rights under the Nigerian Constitution?',
    answer: `FUNDAMENTAL RIGHTS — CHAPTER IV, 1999 CONSTITUTION

Chapter IV of the 1999 Constitution (as amended) guarantees eleven fundamental rights to all persons in Nigeria:

SECTION 33 — RIGHT TO LIFE:
Every person has an inherent right to life. Life shall not be taken intentionally except in execution of a court sentence. Police may use deadly force only to prevent escape of a person unlawfully at large, prevent a crime, or suppress a riot — Force Order 237 governs this.

SECTION 34 — DIGNITY OF HUMAN PERSON:
No person shall be subjected to torture, inhuman or degrading treatment. No person shall be held in slavery or servitude. Forced or compulsory labour is prohibited (with defined exceptions for community service ordered by court).

SECTION 35 — PERSONAL LIBERTY:
You cannot be arrested or detained without lawful cause. If arrested: you must be told the reason within 24 hours (or in a language you understand). You must be charged or released within 24 hours (48 hours if no courthouse is within 40km). Unconstitutional detention may be challenged by habeas corpus.

SECTION 36 — FAIR HEARING:
Every person charged with a criminal offence has the right to a fair and public hearing before an independent court. You are presumed innocent until proven guilty. You have the right to be informed of the charge, time to prepare your defence, and legal representation.

SECTION 37 — PRIVACY:
The privacy of citizens, their homes, correspondence, telephone conversations, and telegraphic communications is guaranteed and protected.

SECTION 38 — FREEDOM OF THOUGHT, CONSCIENCE AND RELIGION:
Every person has the right to freedom of thought, conscience, and religion, including freedom to change religion or belief.

SECTION 39 — FREEDOM OF EXPRESSION AND THE PRESS:
Every person is entitled to freedom of expression including freedom to hold opinions, receive and impart ideas and information without interference. Freedom of the press is guaranteed.

SECTION 40 — FREEDOM OF ASSEMBLY AND ASSOCIATION:
Every person is entitled to assemble freely and associate with other persons, including forming or belonging to any political party, trade union, or other association.

SECTION 41 — FREEDOM OF MOVEMENT:
Every citizen has the right to move freely throughout Nigeria and to reside in any part thereof.

SECTION 42 — FREEDOM FROM DISCRIMINATION:
No citizen shall be subjected to any disability or deprivation solely on grounds of his circumstances of birth, sex, religion, status, ethnic or linguistic association.

SECTION 43 — RIGHT TO ACQUIRE AND OWN PROPERTY:
Every citizen has the right to acquire and own immovable property anywhere in Nigeria.

HOW TO ENFORCE YOUR RIGHTS:
File a motion under the Fundamental Rights (Enforcement Procedure) Rules 2009 at any Federal High Court, State High Court, or FCT High Court. Legal aid is available through the Legal Aid Council (legalaidcouncil.gov.ng).

Source: 1999 Constitution of the Federal Republic of Nigeria (as amended to 2023), Chapter IV, Sections 33–44`
  },

  {
    id: 'arrest-rights',
    category: 'Constitutional Rights',
    keys: ['arrested','arrest','police stop','detention','detain','SARS','SWAT','officer','handcuffed','locked up'],
    question: 'What are my rights when stopped or arrested by the police?',
    answer: `YOUR RIGHTS DURING POLICE ENCOUNTER OR ARREST

WHEN STOPPED (NOT YET ARRESTED):
• You may ask why you are being stopped
• You are NOT obliged to unlock your phone or hand over your device without a court warrant
• You may refuse to follow an officer if no lawful reason for stop is given
• Do not resist physically — comply calmly, document everything you can

UPON ARREST:
1. RIGHT TO KNOW THE REASON (Section 35(3)):
You must be told why you are being arrested in a language you understand.

2. RIGHT TO SILENCE:
You are not required to say anything that may incriminate you. The caution — "You have the right to remain silent" — is legally required under the Administration of Criminal Justice Act 2015 (ACJA) Section 6.

3. RIGHT TO A LAWYER (Section 35(5)):
You have the right to consult a legal practitioner of your choice. The police cannot deny you access to a lawyer. If you cannot afford one, apply to the Legal Aid Council (0800-LEGALAID).

4. RIGHT TO BE CHARGED OR RELEASED (Section 35(4)):
Within 24 hours (or 48 hours if no courthouse within 40km), you must either be charged before a court or released. Holding you beyond this without charge is unlawful detention.

5. NO TORTURE OR DEGRADING TREATMENT (Section 34):
Any form of torture, beating, or degrading treatment is unconstitutional and a criminal offence under the Anti-Torture Act 2017.

6. RIGHT TO BAIL:
Most offences are bailable. The Police Act and ACJA provide for police bail pending arraignment. Bail cannot be denied arbitrarily.

WHAT TO DO IF RIGHTS ARE VIOLATED:
• Note the officer's name, badge number, station, and time
• Contact the Police Service Commission complaints desk: psc.gov.ng
• File a complaint at the National Human Rights Commission: nhrc.gov.ng / 09-523-0183
• Seek a court enforcement order under the Fundamental Rights (Enforcement Procedure) Rules 2009
• Report police brutality on NITIZEN's See-gnal RedFlag platform

Source: 1999 Constitution Sections 33–35; Administration of Criminal Justice Act 2015 (ACJA); Anti-Torture Act 2017; Police Act 2020`
  },

  {
    id: 'freedom-of-information',
    category: 'Constitutional Rights',
    keys: ['freedom of information','foi act','foi','public records','government records','access information','transparency'],
    question: 'How can I access government information under the Freedom of Information Act?',
    answer: `FREEDOM OF INFORMATION ACT (FOI ACT) 2011

The Freedom of Information Act 2011 gives every Nigerian the right to access public records and information held by government institutions.

WHO CAN USE IT:
Any person — Nigerian or foreign — may make an FOI request to any public institution.

WHAT YOU CAN REQUEST:
• Government budgets, expenditure records, and contracts
• Meeting minutes, reports, and policy documents
• Information about any public institution's activities, decisions, or operations
• Personnel records (with some privacy limitations)

HOW TO MAKE A REQUEST:
1. Write a formal request letter to the head of the institution (minister, DG, commissioner, etc.)
2. Clearly identify the document or information you want
3. Submit via hand delivery, registered post, or email where available
4. No reason is required — you do not need to justify your request

TIMELINES:
• The institution must respond within 7 days (extendable to 14 days in complex cases)
• If denied, you must be given reasons in writing

GROUNDS FOR REFUSAL (LIMITED):
Institutions may refuse if disclosure would: endanger national security, prejudice law enforcement, violate another person's privacy, or constitute contempt of court.

IF YOUR REQUEST IS DENIED:
• Appeal to the head of the institution within 30 days
• File a court application at the Federal High Court or relevant State High Court
• The burden of proof lies with the institution to justify refusal

KNOWN LIMITATION:
Many institutions do not comply fully. Advocacy organisations such as the Media Rights Agenda (mediarightsagenda.org) and Paradigm Initiative assist with FOI compliance enforcement.

Source: Freedom of Information Act 2011 (Act No. 4 of 2011); Federal High Court (FOI Practice Directions)`
  },

  // ═══════════════════════════════════
  // CATEGORY 3: CIVIC DUTIES
  // ═══════════════════════════════════
  {
    id: 'civic-duties',
    category: 'Civic Duties & Responsibilities',
    keys: ['civic duty','responsibilities','duties','citizen duty','obligation','tax','jury','community','participation'],
    question: 'What are the civic duties of every Nigerian citizen?',
    answer: `CIVIC DUTIES AND RESPONSIBILITIES OF NIGERIAN CITIZENS

The 1999 Constitution (Chapter II and elsewhere) and Nigeria's civic tradition establish the following duties:

CONSTITUTIONAL DUTIES (Section 24):
Every citizen shall:
(a) Abide by the Constitution, respect its ideals and institutions, the national flag, the national anthem, the national pledge, and legitimate authorities
(b) Help to enhance the power, prestige and good name of Nigeria
(c) Defend Nigeria and render such national service as may be required
(d) Respect the dignity of other citizens and rights and legitimate interests of others
(e) Make positive and useful contribution to the advancement, progress, and well-being of the community
(f) Render assistance to appropriate authorities in the maintenance of law and order
(g) Declare income honestly to appropriate authorities and pay taxes promptly

CIVIC PARTICIPATION DUTIES:
• VOTING: Registering and participating in elections is a civic responsibility. Low voter turnout weakens democratic accountability.
• MONITORING GOVERNMENT: Citizens have both a right and responsibility to track how public funds are spent and how representatives vote.
• COMMUNITY SERVICE: Contributing to your community — whether through local development associations, civic organisations, or voluntary work — is part of active citizenship.
• PAYING TAXES: Tax evasion deprives government of funds needed for public services. Every working Nigerian has a legal obligation to declare income and pay taxes — personal income tax to the State Inland Revenue Service; corporate tax to FIRS.
• JURY DUTY: Nigeria does not use a jury system — judges decide criminal matters.
• REPORTING CRIME AND CORRUPTION: Citizens who witness crime or corruption have a civic obligation to report it to appropriate authorities (police, EFCC, ICPC).
• ENVIRONMENTAL RESPONSIBILITY: Keeping public spaces clean, not blocking drainage, and respecting environmental laws are civic duties under various state and federal laws.

WHY CIVIC DUTIES MATTER:
A democracy functions only when its citizens are active participants, not passive spectators. Nigeria's governance failures are partly sustained by civic disengagement — by citizens who do not vote, do not hold officials accountable, do not pay taxes, and do not report wrongdoing. Active citizenship is the structural reform that makes all other reforms possible.

Source: 1999 Constitution Section 24; Nigeria Tax Act 2025; Environmental Impact Assessment Act`
  },

  // ═══════════════════════════════════
  // CATEGORY 4: POLITICAL KNOWLEDGE
  // ═══════════════════════════════════
  {
    id: 'nigeria-government-structure',
    category: 'Political Knowledge & Democracy',
    keys: ['government structure','three arms','executive','legislature','judiciary','separation of powers','branches','arms of government'],
    question: 'How is the Nigerian government structured?',
    answer: `NIGERIA'S GOVERNMENT STRUCTURE — THREE TIERS, THREE ARMS

FEDERAL STRUCTURE (THREE TIERS):
Nigeria is a federal republic with three tiers of government:

1. FEDERAL GOVERNMENT — Abuja
Handles: defence, foreign policy, currency, immigration, inter-state highways, federal universities, NNPCL/oil & gas regulation

2. STATE GOVERNMENTS (36 States + FCT)
Handles: primary and secondary education, state roads, healthcare (primary), state courts, state police (nascent), agriculture

3. LOCAL GOVERNMENT AREAS (774 LGAs)
Handles: community development, primary school management, local markets, registration of births and deaths

THREE ARMS OF GOVERNMENT:

EXECUTIVE:
• President (federal) / Governor (state) / Chairman (LGA)
• Implements laws, manages government ministries and agencies
• President leads the Federal Executive Council (cabinet of ministers)
• Federal MDAs: over 900 ministries, departments, and agencies

LEGISLATURE:
• National Assembly: Senate (109 seats) + House of Representatives (360 seats)
• State House of Assembly (varies by state, min. 24 members)
• LGA Legislative Councils
• Makes laws, approves budgets, and oversees the executive

JUDICIARY:
• Supreme Court (apex court — final appeal)
• Court of Appeal
• Federal High Court / State High Courts
• Magistrate Courts / Area Courts / Customary Courts
• National Industrial Court (labour disputes)
• Sharia Courts of Appeal (12 northern states)

CHECKS AND BALANCES:
• Executive cannot spend money not appropriated by legislature
• Judiciary can declare any law or executive action unconstitutional
• Senate must confirm key presidential appointments
• The President can veto legislation; legislature can override with 2/3 majority

Source: 1999 Constitution (as amended), Chapters V, VI, VII; Fourth Schedule (LGA functions)`
  },

  {
    id: 'democracy-meaning',
    category: 'Political Knowledge & Democracy',
    keys: ['democracy','democratic','what is democracy','fourth republic','multiparty','republic','civilian rule'],
    question: 'What is democracy and how does Nigeria practice it?',
    answer: `DEMOCRACY AND NIGERIA'S DEMOCRATIC PRACTICE

WHAT IS DEMOCRACY:
Democracy — from the Greek "demos" (people) + "kratos" (rule) — is a system of government in which political power derives from and is exercised by the people, either directly or through elected representatives. Key features: free and fair elections, rule of law, protection of rights, separation of powers, and an independent press.

NIGERIA'S DEMOCRATIC HISTORY:
• 1960–1966: First Republic (parliamentary system; Prime Minister Tafawa Balewa)
• 1966: Military coup (Ironsi); followed by counter-coup (Gowon)
• 1979–1983: Second Republic (presidential system; Shehu Shagari)
• 1983: Military coup (Buhari); Babangida coup 1985; Abacha 1993
• 1993: June 12 election (M.K.O. Abiola declared winner; annulled)
• 1999: Return to civilian rule — Fourth Republic begins (Olusegun Obasanjo)
• 2015: First democratic transfer of power from ruling to opposition party (PDP → APC)
• 2023: Tinubu elected president; Supreme Court upholds result amid disputes

NIGERIA'S DEMOCRATIC MODEL:
Nigeria operates a presidential democracy modelled largely on the United States system:
• Executive president elected directly by the electorate
• Bicameral legislature (Senate + House of Representatives)
• Independent judiciary
• Federal structure with 36 states

DEMOCRATIC CHALLENGES IN NIGERIA:
• Electoral integrity — recurrent disputes over INEC processes and results
• Vote buying — remains pervasive; Electoral Act 2022 strengthens penalties
• Godfatherism — political patronage networks that distort candidate selection
• Low voter turnout — 2023 presidential election saw approximately 27% turnout
• Security threats to voting in some states
• Judiciary's credibility in electoral disputes

June 12 is now celebrated as Democracy Day (declared by President Buhari in 2018) — a recognition that M.K.O. Abiola's 1993 election represented Nigeria's freest election.

Source: 1999 Constitution; Nigerian Electoral History (INEC); Freedom House Nigeria Report 2024`
  },

  {
    id: 'national-assembly',
    category: 'Political Knowledge & Democracy',
    keys: ['national assembly','nass','senate','house of representatives','lawmaker','legislator','senator','bill','legislation','law making'],
    question: 'How does the National Assembly work and what does it do?',
    answer: `THE NATIONAL ASSEMBLY — NIGERIA'S LEGISLATURE

COMPOSITION:
• Senate: 109 senators (3 per state + 1 for FCT Abuja)
• House of Representatives: 360 members representing 360 federal constituencies
• Both chambers elected for 4-year terms

LEADERSHIP:
• Senate President (currently Godswill Akpabio, APC)
• Senate Deputy President
• Speaker of the House (currently Tajudeen Abbas, APC)
• Deputy Speaker

THREE PRIMARY FUNCTIONS:

1. LEGISLATION (Law-Making):
• Any member may introduce a bill
• Bills go through First Reading (formal introduction), Second Reading (debate on principles), Committee stage (detailed scrutiny), Third Reading (final vote)
• Money bills (Appropriation/budget) must originate in the House of Representatives
• Both chambers must pass identical versions; joint conference resolves differences
• President assents or withholds assent; legislature may override with 2/3 majority

2. OVERSIGHT:
• Committees (over 100 across both chambers) monitor executive MDAs
• Summon ministers, heads of agencies to appear and account
• Public hearings on legislation and investigations
• In practice, oversight is frequently weakened by executive-legislature collusion

3. APPROPRIATION (Budget):
• Federal budget is submitted by the President, amended and passed by NASS
• Historically delayed — 2025 budget passed several months late
• Lawmakers insert constituency projects (controversially): BudgIT documented 11,122 insertions worth ₦6.93 trillion in 2025

COST OF NASS:
The 2025 Appropriation Act allocated ₦344.85 billion as statutory transfer to the National Assembly — making Nigeria's legislature among the world's most expensive relative to GDP per capita.

HOW TO FIND YOUR REPRESENTATIVE:
Visit vote.inec.gov.ng to find your LGA and ward; cross-reference with the NASS website (nass.gov.ng) to identify your senator and House member.

Source: 1999 Constitution Sections 47–93; Appropriation Act 2025; BudgIT Budget Analysis 2025`
  },

  // ═══════════════════════════════════
  // CATEGORY 5: NIGERIAN HISTORY
  // ═══════════════════════════════════
  {
    id: 'nigerian-history',
    category: 'Nigerian History & Political Development',
    keys: ['history','colonial','independence','pre-independence','amalgamation','lugard','1914','1960','independence day','republic','nnamdi azikiwe','awolowo','tafawa balewa'],
    question: 'What is the political history of Nigeria from colonialism to the present?',
    answer: `NIGERIA'S POLITICAL HISTORY — CONDENSED TIMELINE

PRE-COLONIAL ERA:
• Nigeria's territory contained hundreds of distinct kingdoms and peoples: Sokoto Caliphate (north), Oyo Empire (southwest), Benin Kingdom (midwest), Igbo city-states and Arochukwu (southeast), Kanuri Borno, Efik and Ibibio coastal states
• Trans-Atlantic slave trade devastated the region from 16th–19th centuries

BRITISH COLONISATION:
• 1861: Lagos annexed as a British Crown Colony
• 1900: Protectorates of Northern and Southern Nigeria established under Frederick Lugard
• 1914: Amalgamation of Northern and Southern Protectorates by Lugard — creating the single entity "Nigeria" (named by Flora Shaw, Lugard's wife)
• Indirect rule system: British governed through existing traditional rulers
• 1946: Richards Constitution — first formal inclusion of Nigerians in governance
• 1951: Macpherson Constitution — regional legislatures established
• 1954: Lyttleton Constitution — federal structure formalised

INDEPENDENCE AND FIRST REPUBLIC (1960–1966):
• October 1, 1960: Independence. Tafawa Balewa (NPC) becomes Prime Minister; Nnamdi Azikiwe becomes ceremonial Governor-General then President (1963)
• Three regions: North, East, West — each with strong regional governments
• 1962–64: Western Region crisis; Action Group crisis
• 1964: Federal election disputed; political crisis deepens
• January 1966: Military coup by Igbo officers (Nzeogwu); counter-coup by northern officers in July; Yakubu Gowon takes power

CIVIL WAR (1967–1970):
• May 1967: Eastern Region declares Republic of Biafra (Ojukwu)
• 30-month civil war; estimated 1–3 million deaths (including famine)
• January 1970: Biafra surrenders; "No victor, no vanquished" policy
• Oil revenue begins to dominate the economy

MILITARY ERA (1970–1979, 1983–1999):
• Gowon (1966–1975) → Murtala Mohammed (1975–1976, assassinated) → Obasanjo (1976–1979) → hands over to civilians
• Second Republic: Shehu Shagari (NPN), 1979–1983
• December 1983: Buhari/Idiagbon coup (recession, corruption cited)
• 1985: Babangida coup; Structural Adjustment Programme (SAP)
• 1990: Failed coup attempt (Orka)
• June 12, 1993: Presidential election — Abiola wins; Babangida annuls result
• August 1993: Interim National Government (Shonekan); November: Abacha coup
• Abacha era (1993–1998): repression, Ogoni executions (Ken Saro-Wiwa), political prisoners, looting of ~$3–5 billion
• June 1998: Abacha dies; Abdulsalami Abubakar transitions to civilian rule
• July 1998: Abiola dies in custody

FOURTH REPUBLIC (1999–PRESENT):
• 1999: Obasanjo (PDP) elected; democracy returns
• 2003: Obasanjo re-elected
• 2007: Umaru Musa Yar'Adua (PDP) elected; Obasanjo's succession plan
• 2010: Yar'Adua dies; Goodluck Jonathan assumes office
• 2011: Jonathan elected; Boko Haram insurgency intensifies
• 2014: #BringBackOurGirls — Chibok kidnapping
• 2015: Muhammadu Buhari (APC) defeats Jonathan — first opposition victory; democratic transfer of power
• 2019: Buhari re-elected
• 2020: #EndSARS protests against police brutality; Lekki Toll Gate shooting
• 2023: Bola Tinubu (APC) elected president; fuel subsidy removed on inauguration day; naira devalued; cost-of-living crisis
• 2025–2026: Tax reform (Nigeria Tax Acts 2025); inflation moderating; 2027 election preparations begin

Source: Crowder, M. (1966) The Story of Nigeria; Falola, T. (1999) The History of Nigeria; Constitution; INEC Electoral Archive`
  },

  // ═══════════════════════════════════
  // CATEGORY 6: PUBLIC FINANCE
  // ═══════════════════════════════════
  {
    id: 'federal-budget',
    category: 'Public Finance & Government Budgets',
    keys: ['budget','appropriation','federal budget','budget process','spending','fiscal','virement','supplementary','MTEF'],
    question: 'How does Nigeria\'s federal budget work?',
    answer: `NIGERIA'S FEDERAL BUDGET — HOW IT WORKS

LEGAL BASIS:
Section 80 of the 1999 Constitution provides that no money shall be withdrawn from the Consolidated Revenue Fund (CRF) without an Appropriation Act. The budget is the federal government's annual spending plan, requiring National Assembly approval.

BUDGET CYCLE:

1. PREPARATION (June–September):
• Ministry of Finance and Budget Office prepare the Medium Term Expenditure Framework (MTEF) and Fiscal Strategy Paper
• Government sets oil price benchmark, exchange rate assumptions, and fiscal targets
• Ministries submit budget proposals to the Budget Office
• Cabinet reviews and approves

2. PRESENTATION (October, by law):
• President presents the Appropriation Bill to a joint session of the National Assembly
• Speech outlines the government's fiscal priorities

3. NATIONAL ASSEMBLY REVIEW (October–December, in theory):
• Senate and House Committees on Appropriations hold hearings
• Ministries defend their budgets before committees
• Members insert constituency projects (a longstanding practice)
• Both chambers pass and harmonise the bill
• In practice, budgets are routinely passed 3–6 months late

4. ASSENT AND IMPLEMENTATION:
• President signs the bill into the Appropriation Act
• Budget Office releases monthly expenditure warrants to MDAs
• Quarterly reports submitted to NASS

2025 BUDGET FACTS:
• Total: ₦54.99 trillion (the largest in Nigeria's history)
• Deficit: ₦13.08 trillion (to be financed by borrowing)
• Debt service: ₦16.3 trillion (approximately 30% of total budget)
• Capital expenditure: ₦20.3 trillion
• Statutory transfers to NASS: ₦344.85 billion

WHERE TO TRACK THE BUDGET:
• Budget Office of the Federation: budgetoffice.gov.ng
• Open Treasury Portal (real-time spending): opentreasury.gov.ng
• BudgIT: public.tableau.com (Tracka)
• NITIZEN's Ledger tracks key sector spending vs. output

Source: 1999 Constitution Section 80–82; Appropriation Act 2025; Budget Office of the Federation`
  },

  {
    id: 'faac',
    category: 'Public Finance & Government Budgets',
    keys: ['faac','federation account','revenue sharing','allocation','states allocation','VAT pool','derivation','oil revenue'],
    question: 'How is government revenue shared between federal, state, and local governments?',
    answer: `REVENUE SHARING IN NIGERIA — THE FAAC SYSTEM

LEGAL BASIS:
The Federation Account Allocation Committee (FAAC) distributes revenues from the Federation Account monthly. The Revenue Sharing Formula is established by the Revenue Mobilisation Allocation and Fiscal Commission (RMAFC) and approved by the National Assembly.

CURRENT SHARING FORMULA (2004, still operative):
• Federal Government: 52.68%
• State Governments (36 states): 26.72% (shared by population, land mass, equality)
• Local Government Councils (774 LGAs): 20.60%

PLUS: 13% Derivation Principle
• Oil-producing states receive an additional 13% of revenues from their territory
• Currently benefiting: Delta, Rivers, Bayelsa, Akwa Ibom, Imo, Ondo, Cross River, Abia, Edo, Lagos (marginal)

VAT DISTRIBUTION:
• Federal Government: 15%
• States: 50%
• LGAs: 35%
• Distributed by states based on equality, population, and derivation
• Contentious: Lagos and Rivers generate most VAT but do not receive proportionate share under the equality-weighted formula

MONTHLY FAAC ALLOCATIONS:
FAAC distributes monthly. January 2026 total shared: approximately ₦1.7 trillion (source: FAAC communiqué, January 2026). Allocations fluctuate with oil production, oil price, and exchange rate.

HOW TO TRACK YOUR STATE'S ALLOCATION:
• RMAFC publishes monthly FAAC allocations on rmafc.gov.ng
• BudgIT's StateofStates report compares state allocations to internally generated revenue (IGR)

WHY THIS MATTERS:
Most Nigerian states are heavily dependent on FAAC (some 80–90% dependent). Low oil production or price directly affects schools, hospitals, and salaries at the state level.

Source: 1999 Constitution Section 162; Revenue Mobilisation Allocation and Fiscal Commission Act; FAAC Monthly Communiqués 2025–2026`
  },

  // ═══════════════════════════════════
  // CATEGORY 7: ECONOMIC POLICY
  // ═══════════════════════════════════
  {
    id: 'inflation-economy',
    category: 'Economic Policy & National Development',
    keys: ['inflation','price','cost of living','economy','economic','naira','exchange rate','recession','gdp','growth'],
    question: 'What is the state of Nigeria\'s economy in 2026?',
    answer: `NIGERIA'S ECONOMIC STATE — 2026 UPDATE

KEY INDICATORS (as of Q1 2026, sourced from NBS and CBN):

INFLATION:
• Headline inflation: 15.38% (March 2026) — NBS CPI Report
• Peak: 34.8% (December 2023) — highest in nearly 30 years
• Food inflation: approximately 21% (March 2026) — still elevated
• Core inflation: approximately 12%
• Moderation driven by CBN tight monetary policy and some naira stabilisation

EXCHANGE RATE:
• Official rate: approximately ₦1,580/$1 (May 2026, CBN)
• Pre-June 2023 rate: approximately ₦460/$1
• Naira was devalued in June 2023 and again in January 2024 as part of unification policy
• FX volatility persists; CBN has intervened periodically

MONETARY POLICY:
• CBN Monetary Policy Rate (MPR): 26.25% (as of January 2026)
• Raised repeatedly since 2023 to combat inflation
• High MPR constrains credit access for businesses and households

GDP AND GROWTH:
• Nigeria's GDP (nominal): approximately $253 billion (2024, World Bank)
• Real GDP growth: approximately 3.4% (2024 NBS estimate)
• Non-oil sector drives most growth; oil sector underperforms due to theft and underinvestment

OIL SECTOR:
• Nigeria's OPEC quota: approximately 1.5 million barrels/day
• Actual production: approximately 1.3–1.5 million bpd (improved from 2022 lows)
• Dangote Refinery operational (2024): Lagos; capacity 650,000 bpd — reduces import dependence
• Petrol pump price: approximately ₦870–1,050/litre (May 2026)

POVERTY AND WELFARE:
• Multidimensional poverty rate: 63% (NBS/UNDP 2022 report — most recent comprehensive figure)
• Over 133 million Nigerians in multidimensional poverty
• Youth unemployment: 6.5% (NBS Q2 2024 — new methodology); significant underemployment estimated at 14–16%

DEBT:
• Total public debt: approximately ₦134 trillion (DMO, December 2024)
• Debt-to-GDP ratio: approximately 54% (within the 55% fiscal rule threshold)
• Debt service consumed approximately 30% of total 2025 budget

Source: NBS Monthly Inflation Report March 2026; CBN Monetary Policy Communiqué January 2026; World Bank Nigeria Economic Update 2025; DMO Debt Report Q4 2024`
  },

  {
    id: 'fuel-subsidy',
    category: 'Economic Policy & National Development',
    keys: ['subsidy','fuel','petrol','subsidy removal','pump price','nnpc','dangote','kerosene'],
    question: 'What happened with the fuel subsidy and what has been the impact?',
    answer: `NIGERIA'S FUEL SUBSIDY — HISTORY, REMOVAL, AND IMPACT

BACKGROUND:
Nigeria imported refined petroleum products for decades despite being a major oil producer, due to the failure of its four public refineries (Port Harcourt I & II, Warri, Kadangara). The government subsidised pump prices — keeping petrol below market cost — at a cost of trillions of naira annually.

COST OF SUBSIDY:
• 2022: NNPC reported subsidy cost of approximately ₦4.7 trillion
• The subsidy was riddled with corruption — ghost volumes, phantom importers, and manipulated landing costs inflated payments to the NNPC subsidy beneficiaries

REMOVAL — MAY 29, 2023:
President Tinubu announced at his inauguration: "Fuel subsidy is gone." The decision was immediate, without transition arrangements, social safety nets in place, or public communication plan.

PRICE IMPACT:
• Before removal: approximately ₦185/litre
• July 2023: approximately ₦620/litre
• Late 2024: exceeded ₦1,000/litre in most states
• May 2026: approximately ₦870–1,050/litre (some moderation after Dangote Refinery supply)

ECONOMIC EFFECTS:
• Transport costs doubled to tripled nationwide
• Food prices rose sharply (supply chain heavily road-dependent)
• Inflation peaked at 34.8% (December 2023)
• Generator fuel costs made SME operations unviable for many

GOVERNMENT RESPONSE:
• ₦8,000 palliative payment announced (widely criticised as inadequate)
• ₦25,000 per month cash transfer to "poorest households" (implementation inconsistent; targeting errors documented by World Bank)
• CNG (Compressed Natural Gas) bus scheme announced — partially implemented

DANGOTE REFINERY:
• The 650,000 bpd Dangote Refinery in Lagos (Africa's largest) began operations in 2024
• Has partially reduced import dependence and helped moderate pump prices
• Full impact on consumer prices developing through 2025–2026

Source: NNPC Annual Report 2022; NBS Inflation Reports 2023–2026; World Bank Nigeria Economic Update 2024; Dangote Refinery operational reports`
  },

  {
    id: 'tax-reform',
    category: 'Economic Policy & National Development',
    keys: ['tax reform','tax act','nigeria tax act 2025','taxation','vat','cit','stamp duty','tax administration','firs','tin'],
    question: 'What do the Nigeria Tax Acts 2025 change about taxation?',
    answer: `NIGERIA TAX REFORM ACTS 2025 — WHAT CHANGED

BACKGROUND:
Nigeria's tax system had over 40 different taxes and levies, multiple revenue authorities, and a notoriously complex compliance environment. The Taiwo Oyedele-led Presidential Committee on Fiscal Policy and Tax Reforms recommended a comprehensive overhaul, enacted in 2025.

THE FOUR ACTS:
1. Nigeria Tax Act 2025 (consolidates income, company, and indirect taxes)
2. Nigeria Tax Administration Act 2025 (unified administration framework)
3. Nigeria Revenue Service (Establishment) Act 2025 (replaces FIRS)
4. Joint Revenue Board (Establishment) Act 2025 (coordinates federal/state/LGA revenue)

KEY CHANGES:

VAT (Value Added Tax):
• Rate unchanged: 7.5% (raised from 5% in 2019)
• Threshold raised: businesses with annual turnover below ₦25 million are exempt from VAT registration
• Expanded exemptions: basic food items, medical services, educational materials

COMPANIES INCOME TAX:
• Large companies (turnover above ₦1 billion): 30%
• Medium companies (₦25m–₦1bn): 20%
• Small companies (below ₦25m): 0% (exempt)
• This is a significant progressive reform benefiting SMEs

PERSONAL INCOME TAX:
• Minimum wage earners fully exempt (income at or below the national minimum wage)
• Progressive rates: 7%–24% on taxable income bands

DEVELOPMENT LEVY:
• Revised from Education Tax (2% of assessable profit) to Development Levy (4%)
• Allocated across: TETFUND, NITDA, NASENI, and a new Student Loan Fund

WHAT HASN'T CHANGED:
• Multiple state and LGA levies remain — the reform is primarily federal
• Informal sector compliance remains the implementation challenge

HOW TO GET YOUR TIN:
Register with the Nigeria Revenue Service (NRS, formerly FIRS) at nrs.gov.ng or any NRS office. TIN is now linked to BVN for individuals.

Source: Nigeria Tax Act 2025; Nigeria Tax Administration Act 2025; FIRS/NRS implementation guidelines; Presidential Committee on Fiscal Policy Report 2024`
  },

  // ═══════════════════════════════════
  // CATEGORY 8: SECURITY & RULE OF LAW
  // ═══════════════════════════════════
  {
    id: 'police-reform',
    category: 'Security & Rule of Law',
    keys: ['police reform','endsars','sars','swat','police act 2020','police brutality','npf','police force','security reform'],
    question: 'What reforms have been made to the Nigeria Police Force since #EndSARS?',
    answer: `NIGERIAN POLICE REFORM AFTER #ENDSARS

THE #ENDSARS MOVEMENT — OCTOBER 2020:
Nigerians, predominantly youth, took to the streets across all states to protest against the Special Anti-Robbery Squad (SARS) — a unit notorious for extortion, torture, unlawful detention, and extrajudicial killings. On October 20, 2020, security forces opened fire on protesters at the Lekki Toll Gate, Lagos — killing protesters (the exact toll disputed; Lagos judicial panel confirmed at least 9 deaths from gunshot wounds).

IMMEDIATE GOVERNMENT RESPONSES:
• SARS officially disbanded — replaced by Special Weapons and Tactics Team (SWAT)
• Presidential directive to all state governments to set up Judicial Panels of Inquiry to receive complaints and award compensation
• Panels sat in most states; many victims received compensation awards

STRUCTURAL REFORMS IMPLEMENTED:
• Police Act 2020 (signed by Buhari): replaced the Police Act of 1943. Key provisions:
  - Police cannot arrest without warrant for minor offences
  - Prohibition of unlawful roadblocks
  - Community policing framework
  - Establishment of Police Accountability Unit
• Police Service Commission now exercises stronger oversight of officer conduct
• IGP's office established a Force Disciplinary Committee

WHAT HAS NOT CHANGED:
• The culture of impunity persists — demonstrated by the killing of Mene Ogidi in April 2026 (Effurun, Delta State)
• ASP Nuhu Usman shot Ogidi, bound and helpless, on video — and was dismissed but as of May 2026, criminal prosecution remains pending
• Most #EndSARS panel recommendations have not been implemented
• State Police: partially approved in 2024 constitutional amendment, implementation ongoing

POLICE ACCOUNTABILITY CONTACTS:
• Police Service Commission: psc.gov.ng
• National Human Rights Commission: nhrc.gov.ng
• NITIZEN See-gnal RedFlag: report any incident

Source: Police Act 2020; Lagos Judicial Panel Final Report 2021; PSC Statement on Mene Ogidi April 2026; Amnesty International Nigeria 2023 Report`
  },

  {
    id: 'state-police',
    category: 'Security & Rule of Law',
    keys: ['state police','devolution security','community police','local police','state security','amotekun','ebubeagu'],
    question: 'Has Nigeria approved state police and how will it work?',
    answer: `STATE POLICE IN NIGERIA — 2024 CONSTITUTIONAL AMENDMENT

BACKGROUND:
Nigeria's 1999 Constitution vested exclusive control of the police in the federal government (Section 214). This meant a single, centralised Nigeria Police Force. Advocates for state police argued that local security challenges — banditry in the northwest, cultism in Rivers, Boko Haram in the northeast — required localised policing with community intelligence.

2024 CONSTITUTIONAL AMENDMENT:
In 2024, the National Assembly passed and the President signed a constitutional amendment permitting states to establish their own police forces. Key provisions:
• Each state may establish a State Police Command
• Subject to the Police Service Commission's oversight framework
• State governors will exercise operational control
• A State Police Council (governor + state officials) to govern each state force
• Federal Police retains jurisdiction over inter-state and national security matters

CURRENT STATUS (May 2026):
• Constitutional basis established
• Enabling legislation — the State Police Act — is being developed
• Some states are at varying stages of planning their forces
• Implementation is expected to be phased over 2026–2028

EXISTING SECURITY OUTFITS:
While formal state police was being debated, several states established security outfits:
• Amotekun (Southwest: Ogun, Oyo, Osun, Ondo, Ekiti, Lagos) — ethnic/community security
• Vigilante Group of Nigeria — community watch, legally recognised
• Ebubeagu (Southeast: Imo, Enugu, Ebonyi, Anambra, Abia) — controversial; human rights concerns raised
• Hisbah Corps (Kano, Zamfara, etc.) — Islamic morality police

CONCERNS:
• Risk of governors using state police for political repression
• Adequate funding and training
• Inter-state jurisdiction coordination

Source: Constitution of the Federal Republic of Nigeria (2024 Amendment); National Assembly proceedings 2024; Premium Times reporting`
  },

  {
    id: 'boko-haram',
    category: 'Security & Rule of Law',
    keys: ['boko haram','iswap','terrorism','insurgency','northeast','chibok','sambisa','military','counterterrorism'],
    question: 'What is the current state of the Boko Haram/ISWAP insurgency?',
    answer: `BOKO HARAM AND ISWAP — NIGERIA'S NORTHEAST INSURGENCY

ORIGINS:
Boko Haram (formally: Jamā'at Ahl as-Sunnah lid-Da'wah wa'l-Jihād) was founded by Mohammed Yusuf in Maiduguri circa 2002. Its name roughly translates to "Western education is forbidden." After Yusuf's extrajudicial killing by police in 2009, the group radicalised into an armed insurgency under Abubakar Shekau.

KEY EVENTS:
• 2009: Boko Haram uprising; Yusuf killed in police custody — major radicalisation trigger
• 2011: UN headquarters bombing in Abuja; church bombings escalate
• 2014: Chibok schoolgirls kidnapping — 276 girls abducted; global #BringBackOurGirls campaign; some released through negotiation
• 2014–2015: Boko Haram controls territory equivalent to Belgium in northeast
• 2016: Shekau pledges allegiance to ISIS; faction becomes ISWAP (Islamic State West Africa Province)
• 2021: Shekau killed in clash with ISWAP; ISWAP dominant
• 2022–2023: Military operations claim significant ISWAP territorial losses

CURRENT STATUS (2026):
• ISWAP remains operationally active in Lake Chad Basin (northeast Nigeria, Niger, Chad, Cameroon)
• Sporadic attacks on military, aid workers, and civilians continue
• Nigerian military claims significant suppression; independent assessment: threat contained but not eliminated
• Over 2 million internally displaced persons remain in the northeast (IOM 2025)
• Humanitarian crisis persists: UNICEF reports severe child malnutrition

GOVERNMENT RESPONSE:
• Multinational Joint Task Force (MNJTF) — Nigeria, Niger, Chad, Cameroon, Benin
• "Safe Schools" initiative rebuilding education
• De-radicalisation programme (Operation Safe Corridor)
• 2024: some Boko Haram commanders surrendered under amnesty

Source: International Crisis Group West Africa reports 2024–2025; ISWAP in West Africa (US Institute of Peace 2024); UNHCR Nigeria 2025`
  },

  // ═══════════════════════════════════
  // CATEGORY 9: HEALTH POLICY
  // ═══════════════════════════════════
  {
    id: 'healthcare-system',
    category: 'Health Policy & Social Services',
    keys: ['health','healthcare','nhis','nhia','bhcpf','hospital','doctor','medical','nhs','health insurance','basic health'],
    question: 'How does Nigeria\'s healthcare system work?',
    answer: `NIGERIA'S HEALTHCARE SYSTEM

STRUCTURE (THREE-TIER):
Primary Healthcare: LGA-managed primary health centres (PHCs) — first point of contact for most Nigerians. Over 30,000 PHCs across the country, though many are non-functional or understaffed.

Secondary Healthcare: State government hospitals — general hospitals in each LGA capital.

Tertiary Healthcare: Federal Teaching Hospitals and Federal Medical Centres — specialist care, medical education.

KEY INSTITUTIONS:
• Federal Ministry of Health and Social Welfare: policy coordination
• National Primary Health Care Development Agency (NPHCDA): manages PHC system
• National Health Insurance Authority (NHIA — formerly NHIS): manages health insurance
• Basic Healthcare Provision Fund (BHCPF): financing mechanism for primary care

BHCPF — WHAT IT IS:
Established under Section 11 of the National Health Act 2014, the BHCPF mandates 1% of the Consolidated Revenue Fund allocation for basic healthcare. It is shared between the NHIA (50%), NPHCDA (45%), and FCT (5%). In practice, allocations have been significantly below the 1% mandate. The fund is intended to make primary healthcare free at point of service — in practice, most PHCs charge patients.

NATIONAL HEALTH INSURANCE:
• NHIA provides formal sector coverage (NHIS contributors)
• Coverage: approximately 5% of Nigerians as of 2024 (mostly federal civil servants)
• Most Nigerians pay out-of-pocket — estimated 75% of health expenditure is OOP
• Vulnerable Group Scheme: nominally covers the poor — implementation patchy

BRAIN DRAIN CRISIS:
• An estimated 16,000 Nigerian doctors have emigrated since 2019 (MDCN data)
• Doctor-to-patient ratio: approximately 1:2,500 (WHO benchmark: 1:600)
• Nurses and midwives emigrate in large numbers to UK, Canada, Saudi Arabia
• "Japa syndrome" (from Yoruba "japa" — to flee) describes this mass exodus

MATERNAL MORTALITY:
• 512 deaths per 100,000 live births (WHO 2023 estimate) — among the world's highest
• Northern Nigeria significantly worse than South

Source: National Health Act 2014; NHIA Annual Report 2024; WHO Nigeria Health Profile 2023; MDCN (Medical and Dental Council of Nigeria) data`
  },

  // ═══════════════════════════════════
  // CATEGORY 10: EDUCATION
  // ═══════════════════════════════════
  {
    id: 'education-system',
    category: 'Education Policy',
    keys: ['education','schools','university','ASUU','strike','ubec','jamb','waec','out of school','tertiary','primary school','secondary school'],
    question: 'What is the state of Nigeria\'s education system?',
    answer: `NIGERIA'S EDUCATION SYSTEM — STRUCTURE AND CHALLENGES

STRUCTURE (6-3-3-4 SYSTEM):
• 6 years: Primary School (ages 6–11) — free and compulsory under UBE Act
• 3 years: Junior Secondary School (JSS 1–3)
• 3 years: Senior Secondary School (SSS 1–3; WAEC/NECO at end)
• 4+ years: Tertiary (university, polytechnic, college of education)

KEY INSTITUTIONS AND BODIES:
• Federal Ministry of Education: policy oversight
• Universal Basic Education Commission (UBEC): manages free basic education funding
• Joint Admissions and Matriculation Board (JAMB): university admissions (UTME)
• West African Examinations Council (WAEC): WASSCE/BECE
• National Examination Council (NECO): alternative to WAEC for SS
• National Universities Commission (NUC): accredits universities; Nigeria has 280+ universities
• ASUU (Academic Staff Union of Universities): lecturers' union

CRISIS INDICATORS:
• Out-of-school children: approximately 10.5 million (UNICEF 2023) — world's largest population
• Primary completion rate: approximately 69% (UNESCO)
• Adult literacy: approximately 62% (NBS 2022)
• Education's share of federal budget: consistently below UNESCO's 15–20% recommendation
• 2022 ASUU Strike: lasted 8 months — students lost academic year

UNIVERSITY FUNDING:
• TETFUND (Tertiary Education Trust Fund): levy on companies' assessable profit; distributes to tertiary institutions
• Federal universities: heavily subsidised (tuition has historically been very low — ongoing debate about cost sharing)
• 2024–2025: Some federal universities raised fees following government directive, provoking student protests

STUDENT LOAN SCHEME:
The Nigerian Education Loan Fund (NELF) was established in 2024 to provide interest-free loans to tertiary students. Implementation is ongoing — first disbursements made in 2025.

Source: UBE Act 2004; UNESCO Nigeria Country Report 2023; UNICEF Education Data 2023; NUC University List 2025`
  },

  // ═══════════════════════════════════
  // CATEGORY 11: ANTI-CORRUPTION
  // ═══════════════════════════════════
  {
    id: 'efcc-icpc',
    category: 'Anti-Corruption & Accountability',
    keys: ['efcc','icpc','corruption','anti-corruption','report corruption','whistleblower','ccb','asset declaration','money laundering'],
    question: 'How do I report corruption and how do anti-corruption agencies work?',
    answer: `ANTI-CORRUPTION IN NIGERIA — AGENCIES AND HOW TO REPORT

ECONOMIC AND FINANCIAL CRIMES COMMISSION (EFCC):
• Established: EFCC (Establishment) Act 2004
• Mandate: investigate and prosecute financial crimes — fraud, money laundering, advance fee fraud, public fund embezzlement, cybercrime (jointly with other agencies)
• Current Chair: Olanipekun Olukoyede (appointed 2023)
• Report: efcc.gov.ng / 0800-3322888 (toll-free) / efccintelligence@efcc.gov.ng
• Zonal offices in Lagos, Abuja, Port Harcourt, Kano, Enugu, Ibadan, and others
• Notable prosecutions: former governors, ministers, corporate executives

INDEPENDENT CORRUPT PRACTICES COMMISSION (ICPC):
• Established: Corrupt Practices and Other Related Offences Act 2000
• Mandate: prosecute corruption in public institutions; educate citizens on corruption; investigate institutional systems for corruption vulnerabilities
• Report: icpc.gov.ng / complaints form on website
• Particularly active on education and public sector corruption

CODE OF CONDUCT BUREAU (CCB) AND TRIBUNAL:
• Public officers (certain grades) must declare assets to CCB every 4 years
• Failure to declare or false declaration is a criminal offence
• CCB refers violators to the Code of Conduct Tribunal (CCT)

MINISTRY OF FINANCE WHISTLEBLOWER POLICY:
• Introduced 2016; still active
• Report financial misconduct: whistleblowing.finance.gov.ng
• Anonymous reporting permitted
• Reward: 2.5–5% of funds recovered as a direct result of your information
• Government has recovered billions of naira through this programme

ASSET RECOVERY:
• Proceeds of Crime (Recovery and Management) Act 2022 provides a framework for confiscating and managing criminally acquired assets
• EFCC maintains a register of confiscated properties

HOW TO REPORT:
1. Gather as much evidence as possible (documents, transaction records, witness details)
2. Submit to EFCC, ICPC, or whistleblower portal
3. You may submit anonymously to the whistleblower portal
4. Report simultaneously on NITIZEN See-gnal RedFlag for public documentation

TRANSPARENCY RANKINGS:
• Transparency International Corruption Perceptions Index (CPI) 2024: Nigeria scored 25/100 (rank 145 of 180 countries) — still critically low

Source: EFCC (Establishment) Act 2004; ICPC Act 2000; Proceeds of Crime Act 2022; TI CPI 2024; Ministry of Finance Whistleblower Guidelines`
  },

  // ═══════════════════════════════════
  // CATEGORY 12: SOCIOPOLITICAL ISSUES
  // ═══════════════════════════════════
  {
    id: 'national-cohesion',
    category: 'Sociopolitical Issues & National Cohesion',
    keys: ['national cohesion','unity','ethnicity','ethnic','tribe','tribalism','religion','religious','north south','division','separatism','biafra','oduduwa','secession'],
    question: 'What are the main sociopolitical fault lines in Nigeria and how are they managed?',
    answer: `NIGERIA'S SOCIOPOLITICAL FAULT LINES AND NATIONAL COHESION

ETHNIC AND LINGUISTIC DIVERSITY:
Nigeria has over 250 ethnic groups and approximately 500 languages. The three major groups — Hausa-Fulani (predominantly north), Yoruba (southwest), Igbo (southeast) — constitute roughly 60–65% of the population. Minority groups (Ijaw, Kanuri, Tiv, Efik, Urhobo, Nupe, etc.) have historically felt marginalised.

THE FEDERAL CHARACTER PRINCIPLE:
Section 14(3) of the 1999 Constitution mandates that the federal government's composition shall reflect Nigeria's "federal character" — ensuring no ethnic group or state dominates appointments. A Federal Character Commission enforces this. In practice, implementation is often political, and the principle has been criticised for prioritising ethnicity over merit.

ZONING:
An informal but powerful political convention dividing elective positions between North and South, and sometimes further between geopolitical zones (Northwest, Northeast, Northcentral, Southeast, Southwest, South-South). The 2023 election broke this informal convention when Tinubu (Lagos, Southwest) succeeded Buhari (Northwest) — breaking the expectation of a Southern Christian/Northern rotation that would have seen a southeasterner take a turn.

RELIGIOUS TENSIONS:
• Nigeria is approximately 50% Muslim, 46% Christian, 4% traditional religion (Pew Research 2022)
• Sharia law operates in 12 northern states for Muslims in civil/family matters
• Plateau State, Kaduna, and parts of the Middle Belt have experienced sustained religious and farmer-herder conflicts
• Interfaith marriage, apostasy, and blasphemy remain flashpoints in some communities

SEPARATIST AGITATIONS:
• IPOB (Indigenous People of Biafra) — Igbo separatist movement led by Nnamdi Kanu (in detention); agitates for Biafra republic; designated terrorist organisation by the Nigerian government
• Oduduwa Republic advocates — fringe Yoruba separatist voices; not as organised as IPOB
• Niger Delta militancy — resource control grievances; periodic pipeline vandalism
• These movements have not achieved constitutional resolution; federal government treats them primarily as security issues rather than political questions

NATIONAL COHESION INSTITUTIONS:
• National Orientation Agency (NOA): civic education and national unity messaging
• Institute for Peace and Conflict Resolution: research and mediation
• National Boundary Commission: manages inter-state boundary disputes

Source: 1999 Constitution Sections 14–15; Federal Character Commission Act; Pew Research Center Global Religious Futures 2022; International Crisis Group Nigeria reports`
  },

  {
    id: 'niger-delta',
    category: 'Sociopolitical Issues & National Cohesion',
    keys: ['niger delta','oil','resource control','militants','MEND','amnesty','derivation','ogoni','ken saro-wiwa','shell','oil spill'],
    question: 'What is the Niger Delta crisis and how does it relate to Nigeria\'s oil resources?',
    answer: `THE NIGER DELTA — OIL, GRIEVANCE, AND ENVIRONMENT

GEOGRAPHY:
The Niger Delta — covering approximately 70,000 km² across Bayelsa, Delta, Rivers, Akwa Ibom, Cross River, Imo, Abia, Ondo, and Edo states — contains Nigeria's oil and gas reserves. It is one of the world's most extensive mangrove ecosystems.

THE RESOURCE CURSE:
Nigeria has earned over $1 trillion from oil since 1960 — yet the Niger Delta communities that sit atop this wealth remain among Nigeria's most underdeveloped. This paradox — oil abundance alongside extreme poverty, environmental devastation, and infrastructure decay — is the central grievance of Niger Delta agitation.

ENVIRONMENTAL DESTRUCTION:
• Oil spills: UNEP's 2011 Ogoniland report estimated it would take 25–30 years and $1 billion to clean up Ogoni alone — the most contaminated oil environment in the world
• Flaring: Nigeria is one of the world's largest gas flarers — burning natural gas as a by-product of oil production, polluting air and wasting energy
• Fishing livelihoods destroyed across thousands of communities

KEN SARO-WIWA AND THE OGONI NINE:
Ken Saro-Wiwa, writer and activist, led the Movement for the Survival of the Ogoni People (MOSOP) against Shell's environmental destruction. He and eight other Ogoni activists were executed by the Abacha government in November 1995 — provoking global outrage and Nigeria's suspension from the Commonwealth.

MILITANCY AND AMNESTY:
• Movement for the Emancipation of the Niger Delta (MEND) and others sabotaged pipelines from the mid-2000s, cutting Nigeria's oil output by over 30%
• 2009: Yar'Adua's Amnesty Programme — militants disarmed for monthly stipends and rehabilitation
• Amnesty remains active; stipends continue though periodically threatened by budget cuts

CURRENT STATUS:
• Pipeline vandalism continues, partly criminal (oil theft — "bunkering") and partly political
• Ogoniland cleanup has begun (HYPREP — Hydrocarbon Pollution Remediation Project) but progress is slow
• 13% derivation remains the only formal revenue concession to oil states

Source: UNEP Ogoniland Assessment 2011; Human Rights Watch (Nigeria) 2024; Amnesty Programme Presidential Amnesty Office; Nigerian Content Development and Monitoring Board`
  },

  // ═══════════════════════════════════
  // CATEGORY 13: ETHICS AND MORALITY
  // ═══════════════════════════════════
  {
    id: 'ethics-public-life',
    category: 'Ethical Values & Public Morality',
    keys: ['ethics','morality','integrity','corruption','bribery','public officer','civil servant','code of conduct','ethical','values'],
    question: 'What ethical standards govern public officers in Nigeria?',
    answer: `ETHICS AND CONDUCT IN NIGERIAN PUBLIC LIFE

CONSTITUTIONAL FRAMEWORK:
The 1999 Constitution (Fifth Schedule — Code of Conduct for Public Officers) sets mandatory ethical standards for all public officers. Categories of public officers covered include: President, Vice President, Governors, Ministers, legislators, judges, military officers, civil servants, directors of state-owned enterprises, and others.

CODE OF CONDUCT OBLIGATIONS:
1. ASSET DECLARATION: Every public officer must declare assets and liabilities on assumption of office, at the end of every 4 years in office, and on leaving office. Declarations are submitted to the Code of Conduct Bureau.

2. PROHIBITION ON FOREIGN ACCOUNTS: No public officer may operate or maintain a foreign bank account except when serving outside Nigeria.

3. PROHIBITION ON BUSINESS INTERESTS: No public officer engaged in full-time government service may engage in trade, business, or other occupation. Blind trusts are permitted.

4. NO ABUSE OF POWER: Public officers may not use their positions for personal gain or to benefit their families.

5. FULL-TIME SERVICE: Public officers in specified grades must give full attention to their public duties.

CODE OF CONDUCT BUREAU AND TRIBUNAL:
Violations are referred to the Code of Conduct Tribunal (CCT). Penalties include: vacation of office, disqualification from public office, and forfeiture of assets. The Senate President Bukola Saraki was tried before CCT in 2015–2017 (ultimately acquitted on most counts).

NATIONAL ETHICS AND INTEGRITY POLICY:
The Buhari administration launched a national ethics policy (2020) under the National Orientation Agency. The Tinubu administration has continued value reorientation messaging. Implementation remains weak.

VOTE BUYING:
Vote buying — paying voters for their votes — is an electoral offence under the Electoral Act 2022 punishable by imprisonment. It remains pervasive. Civil society organisations (YIAGA Africa, Enough is Enough) monitor and document incidents.

WHY ETHICS MATTER FOR GOVERNANCE:
Corruption and ethical failures are estimated to cost Nigeria between $18 billion and $25 billion annually (PricewaterhouseCoopers Nigeria estimate). This is money that should fund hospitals, schools, and infrastructure.

Source: 1999 Constitution Fifth Schedule; Code of Conduct Bureau and Tribunal Act; Electoral Act 2022 Section 121; PwC Nigeria Economic Crime Survey 2024`
  },

  // ═══════════════════════════════════
  // CATEGORY 14: EMERGING ISSUES 2026
  // ═══════════════════════════════════
  {
    id: 'japa-syndrome',
    category: 'Emerging Issues — Nigeria 2026',
    keys: ['japa','emigration','brain drain','abroad','uk','canada','leave nigeria','migration','diaspora'],
    question: 'What is "Japa" and how is mass emigration affecting Nigeria?',
    answer: `"JAPA" — NIGERIA'S MASS EMIGRATION CRISIS

ORIGIN OF THE TERM:
"Japa" is Yoruba slang meaning "to flee" or "to escape." It has become the dominant colloquial term for the mass emigration of Nigerians — particularly educated professionals — to the United Kingdom, Canada, United States, Australia, and Gulf countries.

SCALE (verified figures):
• Doctors: approximately 16,000 Nigerian-trained doctors have emigrated since 2019 (Medical and Dental Council of Nigeria)
• Nurses: Nigerian nurses now constitute one of the largest groups of internationally recruited nurses in the UK (NHS England data 2024)
• UK: approximately 250,000+ Nigerians received UK visas in 2023 (UK Home Office data) — a record
• Canada: Nigeria is among the top 5 source countries for Canadian permanent residents annually
• Students: over 65,000 Nigerians enrolled in UK universities (HESA 2023–24) — the third largest international student group

ROOT CAUSES:
• Economic hardship: inflation, currency depreciation, high unemployment
• Security: insecurity in many states
• Infrastructure collapse: power, roads, healthcare
• Governance failure: poor public services, corruption
• Social aspiration: global connectivity has raised awareness of alternatives

ECONOMIC IMPACT:
• Remittances: Nigerian diaspora remittances reached approximately $20.9 billion in 2023 (World Bank) — Nigeria's largest source of foreign exchange, exceeding oil
• Brain drain cost: Nigeria trains doctors and engineers at public expense who then serve foreign health systems; a significant public subsidy to developed countries
• Skills gap: critical sectors (health, education, technology) are increasingly under-staffed

GOVERNMENT RESPONSE:
• Bilateral agreements with UK and Canada on ethical recruitment (partially implemented)
• Nigeria diaspora bond: designed to attract remittances into capital projects
• Salary increases for health workers (implemented 2024) — effect on emigration unclear

Source: MDCN data; UK Home Office Immigration Statistics 2024; World Bank Migration and Remittances Data 2024; HESA UK 2023–24`
  },

  {
    id: 'digital-economy',
    category: 'Emerging Issues — Nigeria 2026',
    keys: ['fintech','digital economy','tech','startup','paystack','flutterwave','crypto','e-naira','digital','internet','broadband'],
    question: 'What is the state of Nigeria\'s digital economy and tech sector?',
    answer: `NIGERIA'S DIGITAL ECONOMY — 2026

OVERVIEW:
Nigeria has Africa's most active tech startup ecosystem by deal count and funding. Lagos has been described as Africa's Silicon Valley. The digital economy — fintech, e-commerce, healthtech, edtech, agritech — is now a significant and growing part of the formal economy.

FINTECH:
• Nigeria is Africa's fintech hub: Paystack (acquired by Stripe for ~$200m in 2020), Flutterwave (unicorn), OPay (unicorn), Moniepoint (unicorn), Kuda, Carbon
• CBN's Shared Agent Network: over 1.5 million mobile money agents; driving financial inclusion
• Financial inclusion rate: 64% of adults have access to formal or informal financial services (EFInA 2023)
• Over 40 million Nigerians remain financially excluded

E-NAIRA:
• Nigeria launched Africa's first central bank digital currency (CBDC) — the eNaira — in October 2021
• Adoption: limited; approximately 13 million wallets created but active usage is low
• CBN redesign of naira notes (2023) partly aimed at boosting eNaira adoption

INTERNET AND BROADBAND:
• Internet penetration: approximately 55% (Nigerian Communications Commission, 2025)
• Active smartphone users: over 100 million (GSMA)
• Broadband: Nigeria aims for 70% broadband penetration by 2025 (National Broadband Plan 2020–2025) — target not met
• Starlink operational in Nigeria since 2023 — improving rural connectivity

REGULATORY ENVIRONMENT:
• Nigerian Communications Commission (NCC): telecoms regulator
• NITDA (National Information Technology Development Agency): tech policy
• Consumer Protection — Data: Nigeria Data Protection Act 2023 (see NDPC)
• Cybercrimes (Prohibition, Prevention, etc.) Act 2015 — controversial Section 24 (criminalising social media posts that "cause annoyance") widely misused against journalists and activists

CHALLENGES:
• Power: 18/100 on NITIZEN Ledger — tech companies spend significantly on generators
• Talent emigration ("Japa") depletes the developer/engineer pool
• Dollar-denominated costs (servers, licenses) while earning in depreciated naira

Source: EFInA Access to Financial Services Survey 2023; NCC Annual Report 2025; CBN eNaira Annual Report 2024; Partech Africa Tech Report 2024`
  },

  {
    id: 'data-privacy-ndpc',
    category: 'Emerging Issues — Nigeria 2026',
    keys: ['data protection','privacy','NDPC','data act','personal data','gdpr','consent','data rights','NITDA','right to privacy'],
    question: 'What are my data privacy rights in Nigeria?',
    answer: `DATA PRIVACY RIGHTS IN NIGERIA — NDPC FRAMEWORK

LEGAL BASIS:
The Nigeria Data Protection Act 2023 (NDPA) and its predecessor, the Nigeria Data Protection Regulation 2019 (NDPR), establish the framework for personal data protection in Nigeria. The NDPA created the Nigeria Data Protection Commission (NDPC) as the regulatory authority.

YOUR RIGHTS AS A DATA SUBJECT:

1. RIGHT TO INFORMATION:
You must be told — clearly and in plain language — what data is being collected about you, why, how it will be used, and how long it will be kept. This must happen at the point of collection.

2. RIGHT TO CONSENT:
For most categories of data, your explicit, informed consent is required before it is processed. Consent must be freely given, specific, and withdrawable.

3. RIGHT OF ACCESS:
You may request a copy of all personal data an organisation holds about you.

4. RIGHT TO RECTIFICATION:
You may request correction of inaccurate or incomplete data held about you.

5. RIGHT TO DELETION ("RIGHT TO BE FORGOTTEN"):
In certain circumstances, you may request that your data be deleted — particularly if it is no longer needed for the original purpose or if you withdraw consent.

6. RIGHT TO DATA PORTABILITY:
You may request your data in a structured, machine-readable format for transfer to another service.

7. RIGHT TO OBJECT:
You may object to the processing of your data for direct marketing or profiling.

SPECIAL CATEGORIES (requiring highest protection):
Health data, biometric data, genetic data, racial or ethnic origin, religious or political beliefs, financial data, and data concerning children.

HOW TO EXERCISE YOUR RIGHTS:
• Submit a written request to the organisation's Data Protection Officer (DPO) — all significant data processors must appoint one
• If unresolved: file a complaint with the NDPC at ndpc.gov.ng
• NDPC may investigate, impose fines, and require remediation

NITIZEN'S COMMITMENT:
NITIZEN collects only data you voluntarily submit through our forms (contact, submissions, membership). We do not sell your data to third parties. All submissions are processed by Formspree, which operates under GDPR/privacy compliance. You may request deletion of your data at any time by emailing godseffortekene@gmail.com, referencing your submission.

Source: Nigeria Data Protection Act 2023; NDPC Guidelines 2024; NDPR 2019 (still applicable in some contexts)`
  },

  {
    id: 'climate-environment',
    category: 'Emerging Issues — Nigeria 2026',
    keys: ['climate','environment','flooding','drought','deforestation','desertification','sahel','climate change','carbon','green','energy transition'],
    question: 'How is climate change affecting Nigeria?',
    answer: `CLIMATE CHANGE AND NIGERIA'S ENVIRONMENTAL CRISIS

NIGERIA'S CLIMATE PROFILE:
Nigeria sits across several climatic zones — from the Sahel and semi-arid north to tropical rainforest in the south. This makes it acutely vulnerable to multiple climate impacts simultaneously.

KEY CLIMATE THREATS:

1. FLOODING:
• Nigeria experiences severe annual flooding — the worst on record was 2022 (affecting 33 of 36 states; displacing over 1.4 million people, killing over 600)
• The Kainji, Shiroro, and Jebba dams, plus release from Lagdo Dam in Cameroon, exacerbate Niger and Benue flood events
• Urban flooding is worsening in Lagos, Port Harcourt, and Ibadan due to poor drainage and unplanned urbanisation

2. DESERTIFICATION (NORTH):
• The Sahara is advancing southward into Nigeria's north at approximately 0.6 km per year (UNCCD)
• 11 northern states are directly affected; farmlands and water sources are lost
• Desertification is a documented driver of farmer-herder conflicts — as herders move south in search of pasture, competing with farming communities

3. COASTAL EROSION (SOUTH):
• Nigeria's coastline is eroding; Lagos faces long-term submersion risk
• Ocean surge threatens oil infrastructure in the Niger Delta
• Eko Atlantic City (Lagos) is a private reclamation response — privately funded

4. HEAT STRESS:
• Northern Nigeria is experiencing more frequent extreme heat events (above 40°C)
• Agricultural yields are falling; food security threatened

GOVERNMENT RESPONSE:
• Nigeria signed the Paris Agreement (2015); submitted updated Nationally Determined Contributions (NDC 2021) — committing to 20% unconditional and 47% conditional emissions reduction by 2030
• National Climate Change Act 2021: established the Climate Change Council chaired by the President
• Energy Transition Plan (ETP) launched 2022: target of net-zero by 2060; requires $410 billion in investment

PRACTICAL ACTIONS FOR CITIZENS:
• The National Emergency Management Agency (NEMA) and State Emergency Management Agencies (SEMAs) issue flood warnings — register for alerts
• Contact relevant ministries to report illegal dumping, sand mining, or mangrove destruction

Source: UNCCD Desertification Data; NEMA 2022 Flood Report; Nigeria Climate Change Act 2021; Nigeria Energy Transition Plan 2022; IPCC Africa Chapter 2022`
  },

  // ═══════════════════════════════════
  // CATEGORY 15: INSTITUTIONS
  // ═══════════════════════════════════
  {
    id: 'judiciary',
    category: 'Nigerian Institutions & How They Work',
    keys: ['judiciary','court','judge','supreme court','court of appeal','federal high court','magistrate','justice','rule of law','lawsuit','legal','lawyer'],
    question: 'How does Nigeria\'s judiciary work?',
    answer: `NIGERIA'S JUDICIARY — STRUCTURE AND FUNCTION

CONSTITUTIONAL BASIS:
Chapter VII of the 1999 Constitution establishes the judiciary. Judicial independence is guaranteed; judges may not be removed except by a complex process involving the National Judicial Council (NJC) and the President/Governor.

COURT HIERARCHY (FEDERAL):

1. SUPREME COURT OF NIGERIA:
• Apex court; final appellate court in all matters
• 21 justices (including Chief Justice of Nigeria)
• Hears appeals from Court of Appeal; original jurisdiction in inter-governmental disputes
• Current CJN: Justice Kudirat Kekere-Ekun (appointed 2024)

2. COURT OF APPEAL:
• Intermediate appellate court
• Sits in divisions across major cities (Lagos, Abuja, Kano, Enugu, Ibadan, etc.)
• Also handles election petition appeals

3. FEDERAL HIGH COURT:
• Hears matters on federal legislation, constitutional questions, admiralty, EFCC/ICPC prosecutions, company matters, fundamental rights enforcement
• Sits in all 36 states and FCT

4. NATIONAL INDUSTRIAL COURT:
• Handles labour, employment, and trade union matters

STATE COURTS:
• High Courts (general civil and criminal jurisdiction)
• Magistrate Courts (lower criminal/civil)
• Customary Courts (customary law matters)
• Sharia Courts of Appeal (12 northern states — Muslim personal law)

ELECTION TRIBUNALS:
• Governorship and Legislative Election Tribunals: established for each election cycle
• Hear petitions challenging election results
• Appeals go to Court of Appeal and ultimately Supreme Court

CHALLENGES:
• Judicial delays: cases drag for years; backlogs are severe
• Corruption in the judiciary: NJC has sanctioned judges, including for bribery
• Executive pressure on judges: documented interference in sensitive political cases
• Access to justice: legal aid is insufficient; the poor rarely access formal justice

HOW TO ACCESS JUSTICE:
• Legal Aid Council of Nigeria: free legal services for indigents — legalaidcouncil.gov.ng
• Nigerian Bar Association (NBA): lawyer referrals — nigerianbar.org
• Human Rights offices: Federal Ministry of Justice, state ministries

Source: 1999 Constitution Chapter VII; National Judicial Council Guidelines; Access to Justice Report (CLEEN Foundation 2024)`
  },

  {
    id: 'cbn-monetary-policy',
    category: 'Nigerian Institutions & How They Work',
    keys: ['cbn','central bank','monetary policy','mpr','interest rate','banking','bank','financial system','olayemi cardoso','naira'],
    question: 'What does the Central Bank of Nigeria do and how does monetary policy work?',
    answer: `CENTRAL BANK OF NIGERIA (CBN) — ROLE AND MONETARY POLICY

ESTABLISHMENT:
The CBN was established by the Central Bank of Nigeria Act 1958 (now CBN Act 2007). It is Nigeria's apex monetary institution.

CORE MANDATES:
1. Issue legal tender (the naira) and manage currency supply
2. Maintain monetary and price stability
3. Promote a sound financial system
4. Act as banker and financial adviser to the Federal Government
5. Manage Nigeria's external reserves

CURRENT GOVERNOR:
Yemi Cardoso (appointed September 2023); his appointment marked a departure from the Emefiele era (2014–2023) — characterised by unorthodox monetary policies including FX restrictions and multiple exchange rate windows.

MONETARY POLICY COMMITTEE (MPC):
The MPC meets bi-monthly to set the Monetary Policy Rate (MPR) — Nigeria's benchmark interest rate. The MPR influences:
• Commercial bank lending rates
• Inflation
• Exchange rate stability

MPR TIMELINE (2023–2026):
• May 2023: 18.5% (pre-Cardoso)
• July 2024: 26.25% (rapid increases to combat inflation)
• March 2026: 27.5% (further tightening as inflation moderates but remains above target)

FX POLICY REFORM (2023):
Cardoso unified Nigeria's multiple exchange rate windows into a single, market-determined rate in June 2023. This caused immediate naira depreciation (from ₦460 to ₦800+/$1) but was welcomed by the IMF and World Bank as necessary reform.

BANKING REGULATION:
CBN regulates all deposit money banks (Tier 1: Access, GTB, Zenith, UBA, First Bank, FCMB, Sterling, etc.), microfinance banks, and payment service providers through:
• Capital adequacy requirements
• Loan-to-deposit ratios
• KYC (Know Your Customer) compliance
• Consumer protection guidelines

HOW MONETARY POLICY AFFECTS YOU:
• High MPR → expensive loans → less borrowing → less spending → inflation falls
• High MPR also attracts foreign portfolio investment (carry trade), strengthening the naira
• But high rates hurt small businesses that depend on credit

Source: CBN Act 2007 (as amended); CBN MPC Communiqués 2024–2026; IMF Article IV Consultation Nigeria 2025`
  }

];

// ═══════════════════════════════
// SEARCH ENGINE
// ═══════════════════════════════

/**
 * findAnswer — deterministic keyword matching
 * No hallucination possible: returns only pre-written, sourced responses
 * Falls back to honest "not found" rather than generating an answer
 */
function findAnswer(query) {
  const q = query.toLowerCase().trim();
  if (!q || q.length < 3) return null;

  // Score each KB entry
  const scores = ASKNAIJA_KB.map(entry => {
    let score = 0;
    // Keyword matches
    entry.keys.forEach(k => {
      if (q.includes(k)) score += 3;
      // Partial word match
      if (k.length > 4 && q.split(' ').some(w => w.startsWith(k.substring(0,4)))) score += 1;
    });
    // Question similarity
    const qWords = entry.question.toLowerCase().split(' ');
    qWords.forEach(w => { if (w.length > 3 && q.includes(w)) score += 1; });
    return { entry, score };
  });

  scores.sort((a, b) => b.score - a.score);
  const best = scores[0];

  if (best.score >= 2) return best.entry;
  return null;
}

function formatAnswer(entry) {
  return {
    text: entry.answer,
    category: entry.category,
    id: entry.id
  };
}

function getNotFoundResponse(query) {
  return {
    text: `AskNaija's current knowledge base does not have a specific verified entry for "${query}".\n\nOur knowledge base covers:\n• Elections & Voter Registration\n• Constitutional Rights & Arrest\n• Civic Duties & Responsibilities\n• Nigerian History & Political Development\n• National Assembly & Government Structure\n• Public Finance & FAAC\n• Economic Policy, Inflation & Tax Reform\n• Security & Police Reform\n• Healthcare & BHCPF\n• Education & ASUU\n• Anti-Corruption (EFCC/ICPC)\n• National Cohesion & Ethnic Relations\n• Niger Delta & Resource Control\n• Ethics in Public Life\n• Japa & Emigration\n• Digital Economy & Fintech\n• Data Privacy & NDPC\n• Climate Change & Environment\n• The Judiciary\n• CBN & Monetary Policy\n\nFor this query, we recommend:\n• Official sources: inec.gov.ng, budgetoffice.gov.ng, efcc.gov.ng, nbs.gov.ng\n• Verified civic sources: budgit.org, yourbudgit.com, placng.org\n• Nigeria Law: laws.africa/ng\n\nWe expand the knowledge base regularly. If this is an important civic topic, please suggest it at contact.html so we can add it.`,
    category: 'Not Found',
    id: 'not-found'
  };
}

// Categories for UI
const ASKNAIJA_CATEGORIES = [
  { label: 'Elections & Voting', icon: '🗳️', sample: 'How do I register to vote for the 2027 elections?' },
  { label: 'Constitutional Rights', icon: '⚖️', sample: 'What are my fundamental rights under the Nigerian Constitution?' },
  { label: 'Civic Duties', icon: '🤝', sample: 'What are the civic duties of every Nigerian citizen?' },
  { label: 'Political Knowledge', icon: '🏛️', sample: 'How is the Nigerian government structured?' },
  { label: 'Nigerian History', icon: '📜', sample: 'What is the political history of Nigeria from colonialism to the present?' },
  { label: 'Public Finance', icon: '💰', sample: 'How does Nigeria\'s federal budget work?' },
  { label: 'Economic Policy', icon: '📊', sample: 'What is the state of Nigeria\'s economy in 2026?' },
  { label: 'Security & Law', icon: '🔒', sample: 'What reforms have been made to the Nigeria Police Force since #EndSARS?' },
  { label: 'Health Policy', icon: '🏥', sample: 'How does Nigeria\'s healthcare system work?' },
  { label: 'Education', icon: '📚', sample: 'What is the state of Nigeria\'s education system?' },
  { label: 'Anti-Corruption', icon: '🔍', sample: 'How do I report corruption and how do anti-corruption agencies work?' },
  { label: 'National Cohesion', icon: '🇳🇬', sample: 'What are the main sociopolitical fault lines in Nigeria?' },
  { label: 'Ethical Values', icon: '✦', sample: 'What ethical standards govern public officers in Nigeria?' },
  { label: 'Emerging Issues', icon: '🔭', sample: 'What is "Japa" and how is mass emigration affecting Nigeria?' },
  { label: 'Data Privacy', icon: '🛡️', sample: 'What are my data privacy rights in Nigeria?' },
  { label: 'Climate & Environment', icon: '🌿', sample: 'How is climate change affecting Nigeria?' },
  { label: 'Institutions', icon: '⚙️', sample: 'How does Nigeria\'s judiciary work?' },
];

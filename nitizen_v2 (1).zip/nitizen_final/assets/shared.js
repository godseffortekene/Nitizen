/* ═══════════════════════════════════════
   NITIZEN — shared.js  v2
   Civic Intelligence for a New Nigeria
═══════════════════════════════════════ */

// ── NAV SHRINK ──
const mainNav = document.getElementById('main-nav');
if (mainNav) {
  window.addEventListener('scroll', () => {
    mainNav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });
}

// ── MOBILE MENU ──
const navToggle  = document.getElementById('navToggle');
const mobileMenu = document.getElementById('mobileMenu');
if (navToggle && mobileMenu) {
  navToggle.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.toggle('open');
    navToggle.classList.toggle('open', isOpen);
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
  document.addEventListener('click', e => {
    if (!mainNav.contains(e.target) && !mobileMenu.contains(e.target)) {
      mobileMenu.classList.remove('open');
      navToggle.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

// ── SCROLL REVEAL ──
const revealObs = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.07 });
document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

// ── DYNAMIC YEAR ──
const yearEl = document.getElementById('footerYear');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// ── SMOOTH ANCHOR SCROLL (offset for fixed nav) ──
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) {
      e.preventDefault();
      const top = el.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// ── CONTACT FORM ──
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const name    = (this.elements['name']  || {value:''}).value.trim();
    const email   = (this.elements['email'] || {value:''}).value.trim();
    const consent = this.querySelector('[name="consent"]');
    if (!name || !email) { alert('Please fill in your name and email address.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { alert('Please enter a valid email address.'); return; }
    if (consent && !consent.checked) { alert('Please agree to the privacy policy to continue.'); return; }

    const btn = document.getElementById('submitBtn');
    if (btn) { btn.textContent = 'Sending…'; btn.disabled = true; }

    // Encode form data and send to Formspree (replace endpoint or swap with own backend)
    const data = new FormData(this);
    fetch('https://formspree.io/f/hello@nitizen.ng', {
      method: 'POST',
      body: data,
      headers: { 'Accept': 'application/json' }
    })
    .then(r => {
      const success = document.getElementById('formSuccess');
      if (success) { success.style.display = 'block'; this.style.display = 'none'; }
      else { alert('✓ Message sent. We will be in touch shortly.'); }
    })
    .catch(() => {
      // Fallback: open email client
      const msg = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${(this.elements['message']||{value:''}).value}`);
      window.location.href = `mailto:hello@nitizen.ng?subject=NITIZEN%20Contact&body=${msg}`;
      if (btn) { btn.textContent = 'Send Message →'; btn.disabled = false; }
    });
  });
}

// ── GENERIC FORM HANDLER (RedFlag, OpenMic, Ledger, CL Pitch, Critika) ──
['rfForm','omForm','ldgForm','clForm','crtForm'].forEach(id => {
  const form = document.getElementById(id);
  if (!form) return;
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const consent = this.querySelector('[name="consent"]');
    if (consent && !consent.checked) { alert('Please agree to the privacy policy to continue.'); return; }
    const submit = this.querySelector('[type="submit"]');
    if (submit) { submit.disabled = true; submit.textContent = 'Submitting…'; }
    // Simulate submission (connect to backend / Formspree in production)
    setTimeout(() => {
      const success = this.nextElementSibling;
      if (success && success.classList.contains('form-success')) {
        this.style.display = 'none';
        success.style.display = 'block';
        success.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 900);
  });
});

// ── COPY TO CLIPBOARD UTILITY ──
window.copyToClipboard = function(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = orig, 2000);
  }).catch(() => {
    prompt('Copy this:', text);
  });
};
